var classApplyDescriptorGet = require("./classApplyDescriptorGet.js");
var classPrivateFieldGet2 = require("./classPrivateFieldGet2.js");
function _classPrivateFieldGet(e, t) {
  var r = classPrivateFieldGet2(t, e);
  return classApplyDescriptorGet(e, r);
}
module.exports = _classPrivateFieldGet, module.exports.__esModule = true, module.exports["default"] = module.exports;